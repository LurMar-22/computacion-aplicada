#!/bin/bash

mostrar_ayuda() {
    echo "uso: $0 [origen] [destino]"
    echo ""
    echo "Argumentos:"
    echo "  origen   Directorio que se va a respaldar (ej. /var/log)"
    echo "  destino  Directorio donde se guardara el backup (ej. /backup_dir)"
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra este menu de ayuda"
    exit 0
}

if [ "&1" == "-help" ] || [ -z "&1" ] || [ -z "$2" ]; then 
    mostrar_ayuda 
fi 

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no esta disponible."
    exit 1
fi 

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no esta montado"
    exit 1
fi 

FECHA=$(date +"%Y%m%d")
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO_COMPRIMIDO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO_COMPRIMIDO" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

if [ $? -eq 0 ]; then 
    echo "Backup de $ORIGEN creado con éxito en $DESTINO/$ARCHIVO_COMPRIMIDO"
else
    echo "Hubo un error al crear el backup."
    exit 1
fi
